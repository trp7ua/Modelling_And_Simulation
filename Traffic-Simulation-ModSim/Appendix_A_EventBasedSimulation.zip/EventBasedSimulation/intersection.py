import constants

class Intersection:
    def __init__(self,initNumberOfVehicle = 0, initSignalColor = constants.INITIAL_SIGNAL_COLOR , vehicleQueue = [] , servedVehicle = [] , northIntersection = [] , southIntersection = [] , intersectionID = 0): #Signal color : red = 0, green = 1;
        self.numberOfVehicle = initNumberOfVehicle #number of vehicle in the intersection (number of queue)
        self.signalColor = initSignalColor #number of vehicle in the intersection (number of queue)
        self.vehicleQueue = []
        self.servedVehicleID = [] #State of intersection 0:Empty, 1:Occupied
        self.northIntersection = []
        self.southIntersection = []
        self.intersectionID = intersectionID
        
    def incrementVehicleNum(self): #increment number of vehicle (i.e. new vehicle arrives at the intersection)
        self.numberOfVehicle +=  1    
    
    def decrementVehicleNum(self): #decrement number of vehicle (i.e. vehicle leaves the intersection)
        if self.numberOfVehicle > 0 :
            self.numberOfVehicle -= 1
       
    def getVehicleNum(self): 
        return len(self.vehicleQueue)
        #return self.numberOfVehicle

    def getSignalColor(self): 
        return self.signalColor

    def setSignalColor(self, newSignalColor): 
        self.signalColor = newSignalColor
        
    def getVehicleInQueue(self,index):
        return self.vehicleQueue[index]
    
    def deleteVehicleInQueue(self,index):
        self.vehicleQueue.pop(index)
    
    def setVehicleToQueue(self,Vehicle):
        self.vehicleQueue.append(Vehicle)
        
    def setServedVehicleID(self , newVehicleID):
        self.servedVehicleID = newVehicleID
    
    def getServedVehicleID(self):
        return self.servedVehicleID
    
    def setNorthIntersection(self,newIntersection):
        self.northIntersection = newIntersection
        
    def getNorthIntersection(self):
        return self.northIntersection

    def setSouthIntersection(self,newIntersection):
        self.southIntersection = newIntersection
        
    def getSouthIntersection(self):
        return self.southIntersection
    
    def setIntersectionID(self,newID):
        self.intersectionID = newID
    
    def getIntersectionID(self):
        return self.intersectionID