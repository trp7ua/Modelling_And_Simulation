SIMULATION_END_TIME = 30
ARRIVAL_RATE = 4 #Vehicle arrival rate =  1 vehicle / ARRIVAL_RATE  sec
DEPARTURE_RATE = 4 #Vehicle departure rate =  1 vehicle / DEPARTURE_RATE  sec
SIGNAL_CHANGE_RATE = [[3 , 3] , [2 , 4], [4 , 2] , [3 , 3] , [2 , 4] , [3 , 3]] #Signal color change rate [red , green]
INITIAL_SIGNAL_COLOR = 0

SECTION_TRAVEL_TIME = 2

ARRIVAL_EVENT_PRIORITY = 2
SIGNAL_EVENT_PRIORITY = 0
DEPT_EVENT_PRIORITY = 2
SERVICE_COMP_EVENT_PRIORITY = 1

NUMBER_OF_INTERSECTION = 6