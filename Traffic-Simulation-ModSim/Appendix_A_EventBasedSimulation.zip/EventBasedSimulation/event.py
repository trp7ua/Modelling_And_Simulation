import constants
import scheduler
from eventOwner import Vehicle
from eventOwner import TrafficSignal

#General Event class
class Event:
    def __init__(self , myEventOwner , eventType , interval , priority , myIntersection , myScheduler ):
        self.myEventOwner = myEventOwner
        self.eventType = eventType #type of event ('Arrival Event' or 'Departure Event')
        self.interval = interval #time interval between current time and the time when the event happens
        self.myIntersection = myIntersection #Intersection in the event happens
        self.myScheduler = myScheduler #Scheduler to which the event is registered
        self.priority = priority
#Vehicle arrival event
class ArrivalEvent(Event):
    
    #Initialization
    def __init__(self, myEventOwner, eventType , interval , priority , myIntersection, myScheduler):
        Event.__init__(self, myEventOwner , eventType , interval  , priority , myIntersection , myScheduler)
    
    # main process of this event
    def execEvent(self):
        self.myIntersection.incrementVehicleNum() #Increment number of vehicle in myIntersection
        
        #Add myself to queue
        self.myIntersection.setVehicleToQueue(self.myEventOwner);
        
        #If intersection is the first one
        if self.myIntersection.getIntersectionID() == 0:
            #Schedule next arrival event
            nextOwnerID = self.myEventOwner.ownerID + 1;
            nextVehicle = Vehicle("Vehicle", nextOwnerID)
            nextArrivalEvent = ArrivalEvent(nextVehicle , 'Arrival' , constants.ARRIVAL_RATE , constants.ARRIVAL_EVENT_PRIORITY ,  self.myIntersection , self.myScheduler) #Build 
            self.myScheduler.addEvent(nextArrivalEvent) #Set scheduler to next vehicle arrival event
        
        if self.myIntersection.getVehicleNum() == 1: #If there is only one car in myIntersection, call dept event 
                myDepartureEvent = DepartureEvent(self.myEventOwner ,'Departure' , 0 , constants.DEPT_EVENT_PRIORITY , self.myIntersection , self.myScheduler) 
                self.myScheduler.addEvent(myDepartureEvent)
        
      
         
#Vehicle departure event
class DepartureEvent(Event):
    
    #Initialization
    def __init__(self, myEventOwner,  eventType , interval, priority , myIntersection , myScheduler):
        Event.__init__(self, myEventOwner, eventType , interval  , priority , myIntersection , myScheduler)

    # main process of this event
    def execEvent(self):
        
        self.myIntersection.decrementVehicleNum()
        
        
        if self.myIntersection.getSignalColor() == 0:#If the signal is red
            
            intervalToGreen = self.myScheduler.getNextGreenSignalChangeInterval()   
                      
            myDepartureEvent = DepartureEvent(self.myEventOwner , 'Departure' , intervalToGreen  , constants.DEPT_EVENT_PRIORITY , self.myIntersection , self.myScheduler) 
            self.myScheduler.addEvent(myDepartureEvent)
       
        else:#If signal is green 
        
        
            if self.myIntersection.servedVehicleID: #If intersection is occupied, wait until the intersection becomes empty
                interval = self.myScheduler.getNextServiceCompleteInterval()
                #print self.myIntersection.servedVehicleID
                myDepartureEvent = DepartureEvent(self.myEventOwner , 'Departure' , interval , constants.DEPT_EVENT_PRIORITY , self.myIntersection , self.myScheduler)
                self.myScheduler.addEvent(myDepartureEvent)
            else: #If intersection is empty, vehicle pass through the intersection
                
                self.myIntersection.deleteVehicleInQueue(0) #Deque myself 
                self.myIntersection.setServedVehicleID(self.myEventOwner.ownerID)
            
                myServiceCompleteEvent = ServiceCompleteEvent(self.myEventOwner , 'ServiceComplete' , constants.DEPARTURE_RATE , constants.SERVICE_COMP_EVENT_PRIORITY , self.myIntersection , self.myScheduler)
                self.myScheduler.addEvent(myServiceCompleteEvent)
                
                
                nextIntersection = self.myIntersection.getNorthIntersection()
                if nextIntersection:
                    secondArrivalEvent = ArrivalEvent(self.myEventOwner , 'Arrival' , constants.DEPARTURE_RATE + constants.SECTION_TRAVEL_TIME  , constants.ARRIVAL_EVENT_PRIORITY , nextIntersection , self.myScheduler)
                    self.myScheduler.addEvent(secondArrivalEvent)
                
        
                if self.myIntersection.getVehicleNum() > 0: #If there are vehicles on queue, schedule dept event for them.
                    #Schedle next dept event for next vehicle in queue
                    nextVehicleInQueue = self.myIntersection.getVehicleInQueue(0) #get next vehicle
                    nextDepartureEvent = DepartureEvent(nextVehicleInQueue , 'Departure' , constants.DEPARTURE_RATE , constants.DEPT_EVENT_PRIORITY , self.myIntersection , self.myScheduler)
                    self.myScheduler.addEvent(nextDepartureEvent) #set scheduler for next vehicle departure

class ServiceCompleteEvent(Event):         
    def __init__(self,  myEventOwner , eventType , interval , priority , myIntersection , myScheduler):
        Event.__init__(self, myEventOwner, eventType , interval , priority , myIntersection , myScheduler)
        
    def execEvent(self):
        self.myIntersection.setServedVehicleID([])
        
#Traffic signal change event
class SignalEvent(Event):
    
    #Initialization
    def __init__(self,  myEventOwner , eventType , interval , priority , myIntersection , myScheduler):
        Event.__init__(self, myEventOwner, eventType , interval , priority , myIntersection , myScheduler)

    # main process of this event
    def execEvent(self):
        
        
        #print self.myIntersection.getSignalColor() 
        if self.myIntersection.getSignalColor() > 0: #if signal color is green
            self.myIntersection.setSignalColor(0)
            signalChangeRate = constants.SIGNAL_CHANGE_RATE[self.myEventOwner.ownerID][0]
        else:
            self.myIntersection.setSignalColor(1)        
            signalChangeRate = constants.SIGNAL_CHANGE_RATE[self.myEventOwner.ownerID][1]
        
        #print signalChangeRate   
        nextSignalEvent = SignalEvent(self.myEventOwner , 'Signal' , signalChangeRate, constants.SIGNAL_EVENT_PRIORITY, self.myIntersection , self.myScheduler)
        
        self.myScheduler.addEvent(nextSignalEvent) #set scheduler for next vehicle departure


