import constants

#Event owner             
class  EventOwner:
    def __init__(self , ownerType , ownerID ):
        self.ownerType = ownerType
        self.ownerID = ownerID
        
class  Vehicle(EventOwner):
    
    def __init__(self, ownerType , ownerID ):
        EventOwner.__init__(self, ownerType, ownerID)
        
class  TrafficSignal(EventOwner):
    
    def __init__(self, ownerType , ownerID ):
        EventOwner.__init__(self, ownerType, ownerID)