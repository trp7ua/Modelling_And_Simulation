import constants

class EventHistory: #Class that record event. Event history is updated only when there is at least one event at the time stamp. 
    def __init__(self,currentTimeList =[]  , signalStateList = [] , waitingVehicleIDList = [] , servedVehicleIDList = []):
        self.currentTimeList = []
        self.currentTimeList.append(0)
        
        self.signalStateList = []
        self.signalStateList.append(constants.INITIAL_SIGNAL_COLOR) 
        
        self.waitingVehicleIDList = []
        self.waitingVehicleIDList.append(waitingVehicleIDList)
        
        self.servedVehicleIDList = []
        self.servedVehicleIDList.append(servedVehicleIDList)
        
        self.signalHistory = []
        self.vehicleQueueHistory = []
        self.vehicleServiceHistory = []
        #self.waitingVehicleList.append(0)

    def addCurrentTime(self,newCurrentTime):
        self.currentTimeList.append(newCurrentTime)

    def getCurrentTime(self): 
        return self.currentTimeList[len(self.currentTimeList)-1]
    
    def setSignalState(self,newSingalState):
        self.signalStateList.append(newSingalState)
         
    def updateSignalState(self,newSingalState):
        self.signalStateList[len(self.signalStateList)-1] = newSingalState 
    
    def getSignalState(self,time):
        #print self.currentTimeList.index(time)
        return self.signalStateList[self.currentTimeList.index(time)]
    
    def setWaitingVehicle(self, newVehicleQueues):
        tmpList = []
        for index in range(0 , len(newVehicleQueues)):
            tmpList.append(newVehicleQueues[index].ownerID)
        self.waitingVehicleIDList.append(tmpList)
        
    
    def updateWaitingVehicle(self , newVehicleQueues):
        tmpList = []
        for index in range(0 , len(newVehicleQueues)):
            tmpList.append(newVehicleQueues[index].ownerID)
        self.waitingVehicleIDList[len(self.waitingVehicleIDList)-1] = tmpList
         
    def getWaitingVehicle(self,time):
        return self.waitingVehicleIDList[self.currentTimeList.index(time)]

    

    def setServedVehicleID(self, newVehicleID):
        self.servedVehicleIDList.append(newVehicleID)
    
    def updateServedVehicleID(self , newVehicleID):
        self.servedVehicleIDList[len(self.servedVehicleIDList)-1] = newVehicleID
        
    def getServedVehicle(self,time):
        return self.servedVehicleIDList[self.currentTimeList.index(time)]