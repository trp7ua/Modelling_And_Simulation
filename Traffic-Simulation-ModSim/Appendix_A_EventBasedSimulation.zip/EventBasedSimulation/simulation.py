#from  scheduler import scheduler
import numpy as np
import matplotlib.pyplot as plt
import constants
from scheduler import Scheduler
from event import ArrivalEvent
from event import DepartureEvent
from event import SignalEvent
from event import ServiceCompleteEvent
from eventOwner import Vehicle
from eventOwner import TrafficSignal
from intersection import Intersection
from eventHistory import EventHistory
#from zmq.utils.jsonapi import priority


class Analyzer:
    
    def __init__(self , EventHistory):
        self.myEventHistory = EventHistory
        
            #Show simulation result
    def drawFigure(self):
        
        signalHistory = [] 
        signalHistory.append(constants.INITIAL_SIGNAL_COLOR)
        vehicleQueueHistory = []
        vehicleServiceHistory = []
        
        for time in range(0, constants.SIMULATION_END_TIME):
            
            
            
            if time > 0:
                
                #If there were any events in this "time" then myEventHistory.currentTimeList.count(time)) must be greater than 0 
                if (self.myEventHistory.currentTimeList.count(time)) > 0:
                                
                    signalHistory.append(self.myEventHistory.getSignalState(time)) 
                    
                    vehicleQueueHistory.append(self.myEventHistory.getWaitingVehicle(time))
                    vehicleServiceHistory.append(self.myEventHistory.getServedVehicle(time))
                else:   
                    
                    signalHistory.append(signalHistory[time-1])
                    vehicleQueueHistory.append(vehicleQueueHistory[time-1])
                    vehicleServiceHistory.append(vehicleServiceHistory[time -1])
                    
            else:
                vehicleQueueHistory.append(self.myEventHistory.getWaitingVehicle(0))
                vehicleServiceHistory.append(self.myEventHistory.getServedVehicle(0))
                
            if signalHistory[time] == 1:
                plt.plot(time, signalHistory[time]-1, color="g", marker="o", markersize=12)
            elif signalHistory[time] == 0:
                plt.plot(time, signalHistory[time], color="r", marker="o", markersize=12)  
            
            #print time
            currentTimeVehicleInQueueList = vehicleQueueHistory[time]
            currentTimeServedVehicle = vehicleServiceHistory[time]
            
            for i in range(0 , len(currentTimeVehicleInQueueList)):
                plt.text(time, 0.01*(i+1) , currentTimeVehicleInQueueList[i] , fontsize = 6)
            if currentTimeServedVehicle :
                plt.text(time, -0.01 , currentTimeServedVehicle , fontsize = 6)
                
        
        plt.show()
    
    


         
class Simulation:
    
        
    def __init__(self , IntersectionList = [] , currentTime = 0 , EventHistoryList = [] , ):
        self.IntersectionList = IntersectionList
        self.EventHistoryList = EventHistoryList
        self.currentTime = currentTime
        self.scheduler = Scheduler();
        
        for i in range(0 , constants.NUMBER_OF_INTERSECTION):
            newIntersection = Intersection()
            newIntersection.setIntersectionID(i)
            self.IntersectionList.append(newIntersection)
            self.EventHistoryList.append(EventHistory())
        
        #Set north and south intersection
        if constants.NUMBER_OF_INTERSECTION >= 2:    
            for i in range(0 , constants.NUMBER_OF_INTERSECTION):
                if i == 0:
                    self.IntersectionList[i].setNorthIntersection(self.IntersectionList[i+1])
                elif i == constants.NUMBER_OF_INTERSECTION -1 :
                    self.IntersectionList[i].setSouthIntersection(self.IntersectionList[i-1]) 
                else:
                    self.IntersectionList[i].setNorthIntersection(self.IntersectionList[i+1])
                    self.IntersectionList[i].setSouthIntersection(self.IntersectionList[i-1])
                    

        
        for i in range(0 , constants.NUMBER_OF_INTERSECTION):
            newTrafficSignal = TrafficSignal("TrafficSignal" , i)
            newSignalEvent = SignalEvent(newTrafficSignal  , 'Signal' , constants.SIGNAL_CHANGE_RATE[newTrafficSignal.ownerID][constants.INITIAL_SIGNAL_COLOR] , constants.SIGNAL_EVENT_PRIORITY , self.IntersectionList[i] , self.scheduler)
            self.scheduler.addEvent(newSignalEvent)
        
        
        #Create first vehicle instance
        firstVehicle = Vehicle("Vehicle" , 1);
        #Initialization Process
        firstArrivalEvent = ArrivalEvent(firstVehicle , 'Arrival' , constants.ARRIVAL_RATE  , constants.ARRIVAL_EVENT_PRIORITY , self.IntersectionList[0] , self.scheduler)
        self.scheduler.addEvent(firstArrivalEvent)
    
    
if __name__ == "__main__":
          
    mySimulation = Simulation()

    #Main loop

    while mySimulation.currentTime < constants.SIMULATION_END_TIME:
        nextEvent = mySimulation.scheduler.getNextEvent() #Pick up an event on the top of the event list
        mySimulation.currentTime = mySimulation.currentTime + nextEvent.interval #update current time (advance time)
        globalCurrentTime = mySimulation.currentTime
  
        currentEvent = nextEvent.eventType
        mySimulation.scheduler.execEvent() #execute the event
        
        for i in range(0 , len(mySimulation.EventHistoryList)): 
            
            if mySimulation.EventHistoryList[i].getCurrentTime() <  mySimulation.currentTime:
                #"Add" new event to event history

                mySimulation.EventHistoryList[i].addCurrentTime(mySimulation.currentTime)
                mySimulation.EventHistoryList[i].setSignalState(mySimulation.IntersectionList[i].getSignalColor())
                mySimulation.EventHistoryList[i].setWaitingVehicle(mySimulation.IntersectionList[i].vehicleQueue)
                mySimulation.EventHistoryList[i].setServedVehicleID(mySimulation.IntersectionList[i].getServedVehicleID())
                #print firstIntersectionEventHistory.waitingVehicleIDList
                
            elif mySimulation.EventHistoryList[i].getCurrentTime() ==  mySimulation.currentTime:
                #"update" event history at current time
                mySimulation.EventHistoryList[i].updateSignalState(mySimulation.IntersectionList[i].getSignalColor())
                mySimulation.EventHistoryList[i].updateWaitingVehicle(mySimulation.IntersectionList[i].vehicleQueue)
                mySimulation.EventHistoryList[i].updateServedVehicleID(mySimulation.IntersectionList[i].getServedVehicleID())
                
        print '{} event is Executed. Current time is {} and vehicle number is {}'.format(currentEvent , mySimulation.currentTime , mySimulation.IntersectionList[0].getVehicleNum())
        
        

    for time in range(0, constants.SIMULATION_END_TIME):
             
        for i in range(0 , len(mySimulation.EventHistoryList)):      
             
            if time > 0:
            
                #If there were any events in this "time" then firstIntersectionEventHistory.currentTimeList.count(time)) must be greater than 0 
                if (mySimulation.EventHistoryList[i].currentTimeList.count(time)) > 0:
                                 
                    mySimulation.EventHistoryList[i].signalHistory.append(mySimulation.EventHistoryList[i].getSignalState(time)) 
                    mySimulation.EventHistoryList[i].vehicleQueueHistory.append(mySimulation.EventHistoryList[i].getWaitingVehicle(time))
                    mySimulation.EventHistoryList[i].vehicleServiceHistory.append(mySimulation.EventHistoryList[i].getServedVehicle(time))
                else:   
                     
                    mySimulation.EventHistoryList[i].signalHistory.append(mySimulation.EventHistoryList[i].signalHistory[time-1])
                    mySimulation.EventHistoryList[i].vehicleQueueHistory.append(mySimulation.EventHistoryList[i].vehicleQueueHistory[time-1])
                    mySimulation.EventHistoryList[i].vehicleServiceHistory.append(mySimulation.EventHistoryList[i].vehicleServiceHistory[time -1]) 
            else:
                mySimulation.EventHistoryList[i].signalHistory.append(mySimulation.EventHistoryList[i].getSignalState(0))
                mySimulation.EventHistoryList[i].vehicleQueueHistory.append(mySimulation.EventHistoryList[i].getWaitingVehicle(0))
                mySimulation.EventHistoryList[i].vehicleServiceHistory.append(mySimulation.EventHistoryList[i].getServedVehicle(0))
        
  
        
            if mySimulation.EventHistoryList[i].signalHistory[time] == 1:
                plt.plot(time, mySimulation.EventHistoryList[i].signalHistory[time] + i, color="g", marker="o", markersize=12)
            elif mySimulation.EventHistoryList[i].signalHistory[time] == 0:
                plt.plot(time, mySimulation.EventHistoryList[i].signalHistory[time] + i + 1, color="r", marker="o", markersize=12)  
                 
            #print time
            currentTimeVehicleInQueueList = mySimulation.EventHistoryList[i].vehicleQueueHistory[time]
            currentTimeServedVehicle = mySimulation.EventHistoryList[i].vehicleServiceHistory[time]
            
            for j in range(0 , len(currentTimeVehicleInQueueList)):
                plt.text(time, 0.1 + (i + 1) + 0.1 * j , currentTimeVehicleInQueueList[j] , fontsize = 8)  
            if currentTimeServedVehicle :
                plt.text(time, -0.1 + (i + 1) , currentTimeServedVehicle , fontsize = 8)#print time
 

    plt.ylim(0 , constants.NUMBER_OF_INTERSECTION + 1)   
    plt.show()
     
       

        
                  