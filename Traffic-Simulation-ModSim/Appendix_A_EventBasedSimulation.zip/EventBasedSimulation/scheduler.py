import constants

#Event scheduler
class Scheduler:

    #Initialization
    def __init__(self, currentTime = 0): #Constructor
        self.eventList = [] #Event is listed in order of time to be executed. 

    #Add myIvent to the event liset
    def addEvent(self, myEvent): #add myEvent to the event list.  

        self.timeOfExecution =  myEvent.interval #get time when myEvent will be executed
        self.lengthOfEventList = len(self.eventList) #get length of the event list
        
        #print myEvent.eventType
        
        if self.lengthOfEventList  < 1: #if the event list is empty then myEvent is added at the top of the event list
            self.eventList.append(myEvent) 
            
        else:
            
            for listIndex in range(0 , self.lengthOfEventList): #
                
                tempTime = self.eventList[listIndex].interval # get time interval of listIndex th event
                
                
                if  self.timeOfExecution < tempTime:
                    self.eventList.insert( listIndex , myEvent)  
                    #print myEvent.eventType        
                    break
                
                elif self.timeOfExecution == tempTime:
                    if myEvent.priority <  self.eventList[listIndex].priority:
                        #print myEvent.eventType
                        self.eventList.insert( listIndex , myEvent) 
                        break
                    
                if listIndex == self.lengthOfEventList - 1:
                    self.eventList.append(myEvent)



    #(Notice!!) Execute time of event(i.e. interval) is relative time from current time. 
    #This means that execute time is updated everytime event is executed
    def execEvent(self):
        self.nextEvent = self.getNextEvent() #Get event to be executed
        self.nextEventTime = self.nextEvent.interval #Get (relative) time when the event is excecuted


        for index in range(0 , len(self.eventList)):
            self.eventList[index].interval -=  self.nextEventTime

        self.eventList.pop(0) #Remove the event from the event list
        self.nextEvent.execEvent() #Execute event
    
    #
    def getNextEvent(self):
        nextEvent = self.eventList[0]
        return nextEvent
    
    #Get time interval between current time and the time the signal color changes red to green
    def getNextGreenSignalChangeInterval(self):
        
        for index in range(0 , len(self.eventList)):
          
            if self.eventList[index].eventType == 'Signal':
                signalEvent = self.eventList[index]
                if signalEvent.myIntersection.getSignalColor() == 0: #If current signal is red 
                #if self.eventList[index].myIntersection.getSignalColor() == 0: #If current signal is red
                    interval = signalEvent.interval               #Interval = next signal event
                    break
                else:
                    interval = signalEvent.interval +  constants.SIGNAL_CHANGE_RATE[signalEvent.ownerID][0] #Interval = next signal event + interval of red signal
                    break
                    
        return interval
    
    #Get time interval between current time and the time the signal color changes green to red
    def getNextRedSignalChangeInterval(self):
        
        for index in range(0 , len(self.eventList)):
          
            if self.eventList[index].eventType == 'Signal':
                signalEvent = self.eventList[index]
                if signalEvent.myIntersection.getSignalColor() == 0 :#If current signal is green
                    interval = signalEvent.interval          #Interval = next signal event      
                    break
                else:
                    interval = signalEvent.interval +  constants.SIGNAL_CHANGE_RATE[signalEvent.ownerID][1] #Interval = next signal event + interval of green signal
        return interval
    
        #Get time interval between current time and the time the signal color changes green to red
    def getNextServiceCompleteInterval(self):
        
        for index in range(0 , len(self.eventList)):
          
            if self.eventList[index].eventType == 'ServiceComplete':
                interval = self.eventList[index].interval          #Interval = next signal event      
                break
        return interval